using System;
using System.Collections.Generic;
using Xunit;

namespace wi19b060_exam
{
    internal class Devices
    {
        public Dictionary<string, string> list =
            new Dictionary<string, string>();

    }

}
